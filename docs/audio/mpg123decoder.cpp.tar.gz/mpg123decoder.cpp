#include <iostream>
#include <string>
#include <mpg123.h>

using namespace std;

int main()
{
	string inputf;
	string outputf;

	unsigned char* buffer = NULL;
	size_t buffer_size = 0;
	size_t done = 0;

	int err = -1;

	int channels = 0,encoding = 0;
	long rate = 0;
	mpg123_handle *mh;

	cout<<"Enter the file name : ";
	cin>>inputf;
	cout<<"Enter output file name : ";
	cin>>outputf;

	err = mpg123_init();
	if(err != MPG123_OK){
	    cout<<"error in loading mpg123 lib ...\n";
	    return 0;
	}else{
	    cout<<"loaded mpg123 lib  success ...\n";
	}
	mh =mpg123_new(NULL,&err);

	err = mpg123_open(mh,inputf.c_str());
	if(err != MPG123_OK){
	    cout<<"error in opening file ...\n";
	    return 0;
	}else{
	    cout<<"file opened success ...\n";
	}
	err = mpg123_getformat(mh,&rate,&channels,&encoding);
	if(err == MPG123_OK){
	    cout<<"format has been get success ...\n";
	    cout<<"format is : \n"<<"rate : "<<rate<<"\nchannel : "<<channels<<"\nencoding : "<<encoding<<endl;
	}else{
	    cout<<"error in getting format ...\n";
	    return 0;
	}

	buffer_size = mpg123_outblock( mh );
	buffer = (unsigned char*) malloc( buffer_size );

	err = mpg123_read( mh, buffer, buffer_size, &done );
	if(err != MPG123_OK){
	    cout<<"error in reading and decoding buffer"<<endl;
	    return 0;
	}else{
	    cout<<"Readed success"<<endl;
	}

	mpg123_close(mh);
	mpg123_delete(mh);
	mpg123_exit();
	return 0;
}
